#pragma once
#include "Token.h"
#include <iostream>
#include <cctype>
#include <vector>

class Scanner {
private:
	string input;
	unsigned int lineNum = 1;
	vector<Token> tokenVector;
	int stringSize = 0;
	int commentSize = 0;
	bool endOfFile = false;
	bool badString = false;

public:
	Scanner(const string &input) : input(input) {}

	Token scanToken() {

			string value = "";
			TokenType type = TokenType::UNDEFINED;
			unsigned int size = 0;
			
			while (input.size() != 0 && isspace(input.at(0))) {
				if (input.at(0) == '\n')
					lineNum++;
				input = input.substr(1);// input.size() - 1);
			}

			if (input.size() == 0) {
				size = 0;
				type = TokenType::_EOF;
			}
			else if (isalpha(input.at(0))) {
					if (checkSchemes()) {
						size = 7;
						type = TokenType::SCHEMES;					
					}
					else if (checkFacts()) {
						size = 5;
						type = TokenType::FACTS;
					}
					else if (checkRules()) {	
						size = 5;
						type = TokenType::RULES;
					}
					else if (checkQueries() == true) {
						size = 7;
						type = TokenType::QUERIES;
					}
					else if (checkNotString() == true) {
						size = checkId();
						type = TokenType::ID;
					}
			}
			else if (checkString()) {
				size = stringSize;
				type = TokenType::STRING;
				if (endOfFile) {
					cout << "endoffile check" << endl;
					type = TokenType::UNDEFINED;
				}
			}
			else if (checkComment()) {
				size = commentSize;
				type = TokenType::COMMENT;
				if (endOfFile) {
					type = TokenType::UNDEFINED;
				}
			} else 
			switch (input.at(0)) {
				case ',':
					size = 1;
					type = TokenType::COMMA;
					break;
				case '.':
					size = 1;
					type = TokenType::PERIOD;
					break;
				case '?':
					size = 1;
					type = TokenType::Q_MARK;
					break;
				case '(':
					size = 1;
					type = TokenType::LEFT_PAREN;
					break;
				case ')':
					size = 1;
					type = TokenType::RIGHT_PAREN;
					break;
				case ':':
					if (input.at(1) == '-') {
						size = 2;
						type = TokenType::COLON_DASH;
					}
					else {
					size = 1;
					type = TokenType::COLON;
					}
					break;
				case '*':
					size = 1;
					type = TokenType::MULTIPLY;
					break;
				case '+':
					size = 1;
					type = TokenType::ADD;
					break;
				default:
				size = 1;
				type = TokenType::UNDEFINED;
				break;
			}	
			value = input.substr(0, size);
			input = input.substr(size, input.size()-1);
		return Token(type, value, lineNum);
	}




	bool checkSchemes() {
		if (input.substr(0, 7) == "Schemes") {
			return true;
		} else
		return false;
	}

	bool checkFacts() {
		if (input.substr(0, 5) == "Facts") {
			return true;
		} else
		return false;
	}	

	bool checkRules() {
		if (input.substr(0, 5) == "Rules") {
			return true;
		} else
		return false;
	}

	bool checkQueries() {
			//cout << input.substr(0, 7) << endl;
		if (input.substr(0, 7) == "Queries") {
			//cout << "checkQueries function" << endl;
			return true;
		} else
		return false;
	}

	bool checkNotString() {
		if (input.at(0) == '\'') {
			return false;
		}
		else {
			return true;
		}
	}

	int checkId() {
		unsigned int i = 0;
		while (i < input.size() && isalnum(input.at(i))) {
			i++;
		}
		return i;
	}

	bool checkString() {
		unsigned int i = 1;
		if (input.at(0) == '\'') {
			while (input.at(i) != '\'') {
				cout << "current character: " << input.at(i) << endl;
				i++;
				if (i + 1 > input.size()) {
					stringSize = i;
					cout << "end of file reached" << endl;
					endOfFile = true;
					break;
				}
			}
			stringSize = i + 1;
			return true;
		} else
		return false;
	}

	bool checkComment() {
		unsigned int i = 1;
		if (input.at(0) == '#') {
			while (input.at(i) != '\n') {
				i++;
				if (i > input.size()) {
				endOfFile = true;
				}
			}
			commentSize = i;
			return true;
		} else
		return false;
	}

};

